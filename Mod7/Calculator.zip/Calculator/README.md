# Python CLI Calculator

A simple command-line calculator written in Python. This program allows users to perform basic arithmetic operations including addition, subtraction, multiplication, and division. The calculator runs in a loop so users can perform multiple calculations until they choose to exit.


## Features

- Addition
- Subtraction
- Multiplication
- Division
- Input validation for numeric values
- Protection against division by zero
- Results formatted to **3 decimal places**
- Interactive command-line interface


## How It Works

The program consists of two main parts:

1. **Calculator Class**
   - Contains methods for each arithmetic operation:
     - `add(x, y)`
     - `subtract(x, y)`
     - `multiply(x, y)`
     - `divide(x, y)`

2. **run_calculator() Function**
   - Provides the command-line interface
   - Prompts the user to choose an operation
   - Accepts numeric input
   - Displays the result
   - Allows the user to perform additional calculations or exit


## Requirements

- Python 3.x

No external libraries are required.


## How to Run

1. Make sure calculator.py is saved
2. Open a terminal or comand prompt
3. Run the following script:
    python calculator.py

4. if it doesn't run try replacing 'calculator.py' with the exact or relitive file path