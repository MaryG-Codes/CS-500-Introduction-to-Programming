import unittest
from calculator import Calculator

class test_calculator(unittest.TestCase):

    def setUp(self):
        self.calc = Calculator()
    
    def test_add(self):
        self.assertEqual(self.calc.add(2,4), 6, "Addition test failed.")

    def test_subtract(self):
        self.assertEqual(self.calc.subtract(8,3), 5, "Subtraction test failed.")

    def test_multiply(self):
        self.assertEqual(self.calc.multiply(2,4), 8, "Multiply test failed.")

    def test_divide(self):
        self.assertEqual(self.calc.divide(15,5), 3, "Divsion test failed.")

    def test_divide_by_zero(self):
        self.assertEqual(self.calc.divide(5, 0), "Cannot divide by zero!","Failed to check divide by zero.")

if __name__ == '__main__':
    unittest.main()

