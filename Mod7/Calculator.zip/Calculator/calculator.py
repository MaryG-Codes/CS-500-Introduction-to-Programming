# class for arithmetic operation
class Calculator:
    def add(self, x, y):
        return x + y
    def subtract(self, x, y):
        return x - y
    def multiply(self, x, y):
        return x * y
    def divide(self, x, y):
        return x / y if y != 0 else "Cannot divide by zero!"

# main function for calculator
def run_calculator():

    end = "Progam Ending."
    calc = Calculator()

    while True:
        
        print("1.Add 2.Subtract 3.Multiply 4.Divide 5.Exit")
        choice = input("Select Operation (1-5): ")
        
        if choice == '5':
            print(end)
            break
        
        if choice in ('1', '2', '3', '4'):
            try:
                n1 = float(input("Number 1: "))
                n2 = float(input("Number 2: "))

                ops = {
                    '1': calc.add,
                    '2': calc.subtract,
                    '3': calc.multiply,
                    '4': calc.divide
                }

                # result printed to 3 decimal places
                print (f"Result: {ops[choice](n1, n2):.3f}")

                again = input("Do another calculation? (y/n)").lower()
                if again != 'y':
                    print(end)
                    break

            except ValueError:
                print("Invalid input")
        else:
            print("Invalid input")
        

 
if __name__ == "__main__":
     run_calculator() 