from flask import Flask, flash, render_template, request, redirect, url_for, session, jsonify
from flask_basicauth import BasicAuth
from models import db, User, Income, Expense, Savings, SavingsGoal
from datetime import date
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///budget.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'supersecretkey'

# Basic Auth Config
app.config['BASIC_AUTH_USERNAME'] = 'admin'
app.config['BASIC_AUTH_PASSWORD'] = 'password'
basic_auth = BasicAuth(app)

db.init_app(app)

with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = User.query.get(session['user_id'])
    if user is None:
        session.pop('user_id', None)
        return redirect(url_for('login'))
    
    expenses = Expense.query.filter_by(user_id=user.id).all()
    incomes = Income.query.filter_by(user_id=user.id).all()
    savings = Savings.query.filter_by(user_id=user.id).all()
    goal = SavingsGoal.query.filter_by(user_id=user.id).all()

    categories = ['Housing', 'Grocery','Takeout', 'Transportation', 'Entertainment','Medical', 'Insurance']
    category_totals = {cat: sum(e.amount for e in expenses if e.category == cat) for cat in categories}
        

    total_income = sum(i.amount for i in incomes)
    total_expense = sum(e.amount for e in expenses)
    total_saved = sum(u.amount for u in savings)
    savings_goal = sum(o.amount for o in goal)
    remaining = total_income - (total_expense + total_saved)

    # Pie chart
    chart_url = None

    if any(category_totals.values()):
        img = io.BytesIO()

        chart_values = list(category_totals.values()) + [max(0,remaining)]

        if total_income != 0:
            percentages =[(v / total_income) * 100 for v in category_totals.values()]
            chart_labels = [f"{k}: {v:.1f}%" for k,v in zip(category_totals.keys(), percentages)]
        else:
            percentages =[0.0 for _ in category_totals.values()]
            chart_labels = [f"{k}: 0.0%" for k in zip(category_totals.keys(), percentages)]

        chart_labels.append(f"Income Remaining: ${remaining}")

        plt.pie(chart_values, colors=['mediumpurple', 'lightcoral','palegoldenrod','palegreen', 'mediumturquoise', 'lightblue', 'palevioletred','lightgrey'])
        plt.title('Finacial Breakdown')
        plt.legend(labels=chart_labels, loc='upper center', bbox_to_anchor=(0.5, 0.05), fontsize='x-small',ncols=4)
        plt.savefig(img, format='png')
        img.seek(0)
        chart_url = base64.b64encode(img.getvalue()).decode()
        plt.close()



    return render_template('index.html', total_income=total_income, total_expense=total_expense,
                           savings_goal=savings_goal, total_saved=total_saved, remaining=remaining, chart_url=chart_url,
                           incomes=incomes, expenses=expenses)

# Authentication
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash("Username already exists!")
            return redirect(url_for('signup'))
        user = User(username=username)
        user.set_password(password)
        try:
            db.session.add(user)
            db.session.commit()
            flash("Signup successful! Please log in.")
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash("An unexpected error occurred during signup. Please try again.")
            return redirect(url_for('signup'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            return redirect(url_for('home'))
        return "Invalid credentials"
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

# Income / Expense / Savings
@app.route('/add_income', methods=['POST'])
def add_income():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    try:
        amount = float(request.form['amount'])
        if amount < 0:
            flash("Amount must be positive")
            return redirect(url_for('home'))
        description = request.form['description']
        new_income = Income(amount=amount, description=description, date=date.today(), user_id=session['user_id'])
        db.session.add(new_income)
        db.session.commit()
    except ValueError:
        flash("Invalid input for amount")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while adding income")
    return redirect(url_for('home'))

@app.route('/add_expense', methods=['POST'])
def add_expense():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    try:
        amount = float(request.form['amount'])
        if amount < 0:
            flash("Amount must be positive")
            return redirect(url_for('home'))
        category = request.form['category']
        description = request.form['description']
        new_expense = Expense(amount=amount, category=category, description=description, date=date.today(), user_id=session['user_id'])
        db.session.add(new_expense)
        db.session.commit()
    except ValueError:
        flash("Invalid input for amount")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while adding expense")
    return redirect(url_for('home'))

@app.route('/set_savings', methods=['POST'])
def set_savings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    try:
        amount = float(request.form['goal'])
        if amount < 0:
            flash("Amount must be positive")
            return redirect(url_for('home'))
        newGoal = SavingsGoal(amount=amount, date=date.today(), user_id=session['user_id'])
        db.session.add(newGoal)
        db.session.commit()
    except ValueError:
        flash("Invalid input for goal")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while setting savings goal")
    return redirect(url_for('home'))

@app.route('/add_savings', methods=['POST'])
def add_savings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    try:
        amount = float(request.form['amount'])
        if amount < 0:
            flash("Amount must be positive")
            return redirect(url_for('home'))
        new_savings = Savings(amount=amount, date=date.today(), user_id=session['user_id'])
        db.session.add(new_savings)
        db.session.commit()
    except ValueError:
        flash("Invalid input for amount")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while adding savings")
    return redirect(url_for('home'))

# deleting 
@app.route('/delete_income/<int:id>', methods=['POST'])
def delete_income(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    income = Income.query.get_or_404(id)
    if income.user_id != session['user_id']:
        return "Unauthorized", 403

    db.session.delete(income)
    db.session.commit()
    return redirect(url_for('home'))

@app.route('/delete_expense/<int:id>', methods=['POST'])
def delete_expense(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    expense = Expense.query.get_or_404(id)
    if expense.user_id != session['user_id']:
        return "Unauthorized", 403

    db.session.delete(expense)
    db.session.commit()
    return redirect(url_for('home'))

@app.route('/reset_all_to_zero', methods=['POST'])
def reset_all_to_zero():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    Income.query.filter_by(user_id=session['user_id']).delete()
    Expense.query.filter_by(user_id=session['user_id']).delete()
    Savings.query.filter_by(user_id=session['user_id']).delete()
    SavingsGoal.query.filter_by(user_id=session['user_id']).delete()

    db.session.commit()
    return redirect(url_for('home'))

# Secure API
@app.route('/api/expenses', methods=['GET'])
@basic_auth.required
def api_expenses():
    expenses = Expense.query.all()
    return jsonify([{'user': e.user_id, 'amount': e.amount, 'category': e.category} for e in expenses])

if __name__ == '__main__':
    app.run(debug=True)

