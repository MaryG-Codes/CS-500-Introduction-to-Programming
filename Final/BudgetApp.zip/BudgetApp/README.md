# BudgetApp

A simple Flask-based personal budget tracking web app with user authentication, income/expense tracking, savings and goal management, and a generated pie chart of financial breakdown.

## Features

- User sign-up, login, logout via session.
- Income, expense, savings and savings goal records.
- Add/delete transactions.
- Reset all records for the logged-in user.
- Basic chart visualization (matplotlib pie chart) of category spending and remaining funds.
- Protected API endpoint with basic auth for viewing expenses (`/api/expenses`).
- SQLite persistence (`budget.db`).

## Project Structure

- `app.py`: Flask application and routes.
- `models.py`: SQLAlchemy models (User, Income, Expense, Savings, SavingsGoal).
- `templates/`: HTML templates (`base.html`, `index.html`, `login.html`, `signup.html`).
- `static/styles.css`: Styling.
- `test.py`: Unit tests using `unittest`.
- `env/`: local Python virtualenv (not committed in most repos).

## Requirements

- Python 3.10+ (tested 3.14 in workspace)
- Flask
- Flask-SQLAlchemy
- Flask-BasicAuth
- Werkzeug
- Matplotlib

## Setup

1. Clone/copy this repository.
2. Create and activate a virtual environment:

```bash
python -m venv env
# Windows PowerShell
env\Scripts\Activate.ps1
# Windows CMD
env\Scripts\activate.bat
```

3. Install dependencies:

```bash
pip install flask flask_sqlalchemy flask_basicauth matplotlib
```

4. Run the app:

```bash
python app.py
```

5. Open browser at `http://127.0.0.1:5000/`.

## Usage

- Navigate to `/signup` to create an account.
- Login at `/login`.
- Add incomes, expenses, and savings using the dashboard forms.
- Set a savings goal and track progress.
- Delete entries and use reset to clear the current user data.

## API

The app exposes one secure API endpoint:

- `GET /api/expenses` (Basic Auth required)

Default Basic Auth credentials are configured in `app.py`:

- Username: `admin`
- Password: `password`

## Tests

Run unit tests with:

```bash
python test.py
```

## Notes

- Database file `budget.db` is generated automatically on first run.
- `SECRET_KEY` in `app.py` should be changed for production.
- For production use, disable `debug=True` and configure proper credentials and secure session management.
