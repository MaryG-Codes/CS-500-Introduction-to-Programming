import unittest
import os
from datetime import date
from app import app, db, User, Income, Expense

class BudgetAppTestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
        self.app = app.test_client()
        with app.app_context():
            db.create_all()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()
        if os.path.exists('test.db'):
            os.remove('test.db')

    def test_user_signup_login(self):
        with app.app_context():
            user = User(username="testuser")
            user.set_password("testpass")
            db.session.add(user)
            db.session.commit()
            self.assertTrue(user.check_password("testpass"))

    def test_add_income_expense(self):
        with app.app_context():
            user = User(username="testuser2")
            user.set_password("testpass")
            db.session.add(user)
            db.session.commit()
            income = Income(amount=1000, description="Salary", date=date(2026, 3, 30), user_id=user.id)
            db.session.add(income)
            db.session.commit()
            self.assertEqual(Income.query.first().amount, 1000)

    def test_delete_income(self):
        with app.app_context():
            user = User(username="delete_test")
            user.set_password("pass")
            db.session.add(user)
            db.session.commit()
            income = Income(amount=500, user_id=user.id)
            db.session.add(income)
            db.session.commit()
            db.session.delete(income)
            db.session.commit()
            self.assertEqual(Income.query.count(), 0)

if __name__ == '__main__':
    unittest.main()